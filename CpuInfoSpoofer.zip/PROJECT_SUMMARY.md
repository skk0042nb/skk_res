# CPU Info Spoofer - 项目总结

## 项目概述

这是一个基于 **Zygisk 1.4.5** 的 CPU 信息伪装模块，通过 Native Inline Hook (GOT 劫持) 技术全面修改系统对 CPU 信息的读取，伪装为 **HiSilicon Kirin 9000S** 处理器。

## 技术架构

```
┌─────────────────────────────────────────────────────────────┐
│                     Magisk Manager                          │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────┐     │
│  │ post-fs-data│    │  service.sh │    │  Zygisk    │     │
│  │   .sh       │    │             │    │   Engine   │     │
│  └──────┬──────┘    └─────────────┘    └──────┬──────┘     │
│         │                                     │             │
│         ▼                                     ▼             │
│  ┌──────────────────────────────────────────────────────┐   │
│  │              libcpuinfo_spoofer.so                   │   │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  │   │
│  │  │  GOT Hook   │  │  File Hook  │  │  Prop Hook │  │   │
│  │  │  Manager    │  │  Manager    │  │  Manager   │  │   │
│  │  └─────────────┘  └─────────────┘  └─────────────┘  │   │
│  └──────────────────────────────────────────────────────┘   │
│         │                                     │             │
│         ▼                                     ▼             │
│  ┌─────────────┐    ┌─────────────┐    ┌─────────────┐     │
│  │  /proc/cpuinfo│   │ /sys/.../cpu │   │ SystemProps │     │
│  │  (Spoofed)  │    │  (Spoofed)  │    │  (Spoofed) │     │
│  └─────────────┘    └─────────────┘    └─────────────┘     │
└─────────────────────────────────────────────────────────────┘
```

## Hook 覆盖的函数

### 文件操作
- `open`, `openat`: 拦截文件打开，对伪装文件返回 `/dev/null` fd
- `read`, `pread`: 拦截读取，返回伪装数据
- `fopen`: 拦截文件打开，返回包含伪装内容的临时文件
- `fread`, `fgets`: 拦截 stdio 读取
- `fclose`: 清理临时文件映射
- `stat`, `fstat`, `lstat`: 返回伪装文件的大小和属性
- `access`: 伪装文件总是返回存在

### 系统属性
- `__system_property_get`: 拦截属性获取，返回伪装的 CPU 相关属性

## 文件清单

```
CpuInfoSpoofer/
├── module.prop              # Magisk 模块描述
├── post-fs-data.sh          # 开机脚本
├── service.sh               # 后台服务
├── customize.sh             # 安装时自定义
├── zygisk/
│   ├── config.prop          # Zygisk 配置
│   └── arm64-v8a/
│       └── libcpuinfo_spoofer.so  # (需编译)
├── jni/
│   ├── main.cpp             # Hook 核心 (~800 行)
│   ├── Android.mk           # NDK 构建配置
│   ├── Application.mk       # NDK 应用配置
│   └── build.sh             # 构建脚本
├── README.md                # 详细文档
├── INSTALL.md               # 安装指南
└── PROJECT_SUMMARY.md       # 本文件
```

## 编译步骤

```bash
export ANDROID_NDK_HOME=/path/to/android-ndk-r26
cd CpuInfoSpoofer/jni
chmod +x build.sh
./build.sh $ANDROID_NDK_HOME
```

## 伪装数据速查

| 项目 | 伪装值 |
|------|--------|
| CPU 型号 | Kirin 9000S |
| CPU 核心 | 8 (1+3+4 big.LITTLE) |
| ro.hardware | chagall |
| ro.soc.model | kirin9000s |
| ABI | arm64-v8a |

## 注意事项

1. **必须编译 native 库**：核心功能依赖 `libcpuinfo_spoofer.so`
2. **Zygisk 必须启用**：在 Magisk 设置中开启
3. **需要重启**：安装后必须重启设备
4. **Shell 限制**：`adb shell` 中可能看到真实信息，但应用层已被伪装

## 调试

```bash
cat /data/local/tmp/cpuinfo_spoofer.log
tail -f /data/local/tmp/cpuinfo_spoofer.log
```