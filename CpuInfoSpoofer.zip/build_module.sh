#!/bin/bash
# 打包脚本：将模块打包为 Magisk 可安装的 zip 文件
set -e

MODULE_NAME="cpuinfo_spoofer"
ZIP_NAME="${MODULE_NAME}.zip"
TEMP_DIR="/tmp/${MODULE_NAME}_build"

echo "Building Magisk module: $MODULE_NAME"

# 清理旧文件
rm -f "$ZIP_NAME"
rm -rf "$TEMP_DIR"

# 创建临时目录结构
mkdir -p "$TEMP_DIR/$MODULE_NAME"
mkdir -p "$TEMP_DIR/$MODULE_NAME/zygisk/arm64-v8a"

# 复制模块文件
cp module.prop "$TEMP_DIR/$MODULE_NAME/"
cp post-fs-data.sh "$TEMP_DIR/$MODULE_NAME/"
cp service.sh "$TEMP_DIR/$MODULE_NAME/"
cp customize.sh "$TEMP_DIR/$MODULE_NAME/"
cp zygisk/config.prop "$TEMP_DIR/$MODULE_NAME/zygisk/"

# 检查是否已编译 native 库
if [ -f "libs/arm64-v8a/libcpuinfo_spoofer.so" ]; then
    cp "libs/arm64-v8a/libcpuinfo_spoofer.so" "$TEMP_DIR/$MODULE_NAME/zygisk/arm64-v8a/"
    echo "Native library included."
else
    echo "WARNING: Native library not found!"
    echo "Please compile the native library first by running:"
    echo "  cd jni && ./build.sh <path-to-ndk>"
    echo ""
    echo "Creating module zip without native library (will not work until compiled)."
fi

# 添加 README
cp README.md "$TEMP_DIR/$MODULE_NAME/"

# 创建 META-INF 用于 Magisk 安装
mkdir -p "$TEMP_DIR/META-INF/com/google/android"
cat << 'EOF' > "$TEMP_DIR/META-INF/com/google/android/updater-script"
# Magisk module installation script
# No special installation needed for Magisk modules
EOF

# 打包
cd "$TEMP_DIR"
zip -r "$OLDPWD/$ZIP_NAME" . -x "*.DS_Store"

# 清理
cd "$OLDPWD"
rm -rf "$TEMP_DIR"

echo ""
echo "Build complete!"
echo "Output: $ZIP_NAME"
echo ""
echo "To install:"
echo "1. Transfer $ZIP_NAME to your device"
echo "2. Open Magisk Manager"
echo "3. Go to Modules → Install from storage"
echo "4. Select $ZIP_NAME"
echo "5. Reboot"