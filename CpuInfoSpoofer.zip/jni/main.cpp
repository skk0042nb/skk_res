/*
 * CPU Info Spoofer - Zygisk Native Module
 * Architecture: ARM64
 * Technique: GOT (Global Offset Table) Hijacking + Fallback Inline Hook
 * Target: Android 8.0+ (API 26+)
 */

#include <jni.h>
#include <string>
#include <map>
#include <mutex>
#include <unordered_map>
#include <android/log.h>
#include <dlfcn.h>
#include <link.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <cstring>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cinttypes>
#include <atomic>
#include <thread>
#include <vector>

#define LOG_TAG "CpuInfoSpoofer"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, LOG_TAG, __VA_ARGS__)

// ==================== 伪装数据定义 ====================

// 伪装后的 /proc/cpuinfo 内容
static const char* SPOOFED_CPUINFO = R"(Processor       : AArch64 Processor rev 0 (aarch64)
Features        : fp asimd evtstrm aes pmull sha1 sha2 crc32 atomics fphp asimdhp
CPU implementer : 0x48
CPU architecture: 8
CPU variant     : 0x1
CPU part        : 0xd0c
CPU revision    : 0

processor       : 0
BogoMIPS        : 26.00
CPU implementer : 0x48
CPU architecture: 8
CPU variant     : 0x1
CPU part        : 0xd0c
CPU revision    : 0

processor       : 1
BogoMIPS        : 26.00
CPU implementer : 0x48
CPU architecture: 8
CPU variant     : 0x2
CPU part        : 0xd0a
CPU revision    : 0

processor       : 2
BogoMIPS        : 26.00
CPU implementer : 0x48
CPU architecture: 8
CPU variant     : 0x2
CPU part        : 0xd0a
CPU revision    : 0

processor       : 3
BogoMIPS        : 26.00
CPU implementer : 0x48
CPU architecture: 8
CPU variant     : 0x2
CPU part        : 0xd0a
CPU revision    : 0

processor       : 4
BogoMIPS        : 26.00
CPU implementer : 0x48
CPU architecture: 8
CPU variant     : 0x3
CPU part        : 0xd0b
CPU revision    : 0

processor       : 5
BogoMIPS        : 26.00
CPU implementer : 0x48
CPU architecture: 8
CPU variant     : 0x3
CPU part        : 0xd0b
CPU revision    : 0

processor       : 6
BogoMIPS        : 26.00
CPU implementer : 0x48
CPU architecture: 8
CPU variant     : 0x3
CPU part        : 0xd0b
CPU revision    : 0

processor       : 7
BogoMIPS        : 26.00
CPU implementer : 0x48
CPU architecture: 8
CPU variant     : 0x3
CPU part        : 0xd0b
CPU revision    : 0

Hardware        : HiSilicon Kirin 9000S
)";

// 伪装后的 CPU 数量
static const char* SPOOFED_CPU_PRESENT = "0-7";
static const char* SPOOFED_CPU_ONLINE = "0-7";

// 伪装后的 CPU 频率 (单位: KHz)
static const char* SPOOFED_FREQ_MAX = "2800000";   // 2.8 GHz
static const char* SPOOFED_FREQ_MIN = "480000";    // 480 MHz
static const char* SPOOFED_FREQ_MAX_1 = "2800000"; // Cpu0 (超大核)
static const char* SPOOFED_FREQ_MAX_4 = "2520000"; // Cpu4 (大核)
static const char* SPOOFED_FREQ_MAX_7 = "2048000"; // Cpu7 (小核)

// 伪装后的 CPU 拓扑信息
static const char* SPOOFED_CPU_CLUSTER0_CPUS = "0";
static const char* SPOOFED_CPU_CLUSTER1_CPUS = "1-3";
static const char* SPOOFED_CPU_CLUSTER2_CPUS = "4-7";

// 需要伪装的系统属性
static const std::map<std::string, std::string> SPOOFED_PROPS = {
    {"ro.product.cpu.abi", "arm64-v8a"},
    {"ro.product.cpu.abilist", "arm64-v8a,armeabi-v7a,armeabi"},
    {"ro.product.cpu.abilist32", "armeabi-v7a,armeabi"},
    {"ro.product.cpu.abilist64", "arm64-v8a"},
    {"ro.hardware", "chagall"},
    {"ro.hardware.chipname", "kirin9000s"},
    {"ro.soc.model", "kirin9000s"},
    {"ro.chipname", "kirin9000s"},
    {"ro.arch", "arm64"},
    {"ro.product.cpu.abi8", "arm64-v8a"},
    {"ro.product.cpu.abilist8", "arm64-v8a"},
    {"persist.sys.timezone", "Asia/Shanghai"}, // 可选，防止时区检测
};

// ==================== 工具函数 ====================

// 检查路径是否是需要伪装的 CPU 相关文件
static bool is_spoofed_path(const std::string& path) {
    if (path == "/proc/cpuinfo") return true;
    if (path == "/sys/devices/system/cpu/present") return true;
    if (path == "/sys/devices/system/cpu/online") return true;
    if (path.find("/sys/devices/system/cpu/cpu") != std::string::npos) {
        if (path.find("/cpufreq/cpuinfo_max_freq") != std::string::npos) return true;
        if (path.find("/cpufreq/cpuinfo_min_freq") != std::string::npos) return true;
        if (path.find("/cpufreq/scaling_max_freq") != std::string::npos) return true;
        if (path.find("/cpufreq/scaling_min_freq") != std::string::npos) return true;
        if (path.find("/topology/physical_package_id") != std::string::npos) return true;
        if (path.find("/topology/core_id") != std::string::npos) return true;
        if (path.find("/topology/thread_siblings_list") != std::string::npos) return true;
        if (path.find("/topology/cluster_id") != std::string::npos) return true;
    }
    if (path.find("/sys/devices/system/cpu/protocols") != std::string::npos) return true;
    if (path.find("/proc/device-tree/compatible") != std::string::npos) return true;
    return false;
}

// 获取伪装的文件内容
static std::string get_spoofed_content(const std::string& path) {
    if (path == "/proc/cpuinfo") {
        return SPOOFED_CPUINFO;
    }
    if (path == "/sys/devices/system/cpu/present") {
        return SPOOFED_CPU_PRESENT;
    }
    if (path == "/sys/devices/system/cpu/online") {
        return SPOOFED_CPU_ONLINE;
    }
    
    // CPU 频率文件
    if (path.find("/cpufreq/cpuinfo_max_freq") != std::string::npos) {
        if (path.find("cpu0") != std::string::npos || path.find("cpu 0") != std::string::npos) {
            return SPOOFED_FREQ_MAX_1;
        }
        if (path.find("cpu4") != std::string::npos || path.find("cpu 4") != std::string::npos) {
            return SPOOFED_FREQ_MAX_4;
        }
        if (path.find("cpu7") != std::string::npos || path.find("cpu 7") != std::string::npos) {
            return SPOOFED_FREQ_MAX_7;
        }
        return SPOOFED_FREQ_MAX;
    }
    if (path.find("/cpufreq/cpuinfo_min_freq") != std::string::npos ||
        path.find("/cpufreq/scaling_min_freq") != std::string::npos) {
        return SPOOFED_FREQ_MIN;
    }
    if (path.find("/cpufreq/scaling_max_freq") != std::string::npos) {
        if (path.find("cpu0") != std::string::npos) return SPOOFED_FREQ_MAX_1;
        if (path.find("cpu4") != std::string::npos) return SPOOFED_FREQ_MAX_4;
        return SPOOFED_FREQ_MAX;
    }
    
    // 拓扑信息
    if (path.find("physical_package_id") != std::string::npos) return "0";
    if (path.find("core_id") != std::string::npos) {
        size_t pos = path.find("cpu") + 3;
        if (pos != std::string::npos) {
            int cpu = path[pos] - '0';
            if (cpu == 0) return "0";
            if (cpu >= 1 && cpu <= 3) return "1";
            if (cpu >= 4 && cpu <= 7) return "2";
        }
        return "0";
    }
    if (path.find("thread_siblings_list") != std::string::npos) {
        size_t pos = path.find("cpu") + 3;
        if (pos != std::string::npos) {
            int cpu = path[pos] - '0';
            return std::to_string(cpu);
        }
        return "0";
    }
    
    return "";
}

// ==================== GOT 劫持实现 ====================

// 获取当前模块的 link_map
static struct link_map* get_link_map() {
    Dl_info info;
    if (dladdr((void*)get_link_map, &info) == 0) return nullptr;
    return (struct link_map*)info.dli_fbase;
}

// 获取目标函数在 GOT 中的条目地址
static void** find_got_entry(const char* func_name) {
    // 获取原始函数地址
    void* orig_func = dlsym(RTLD_NEXT, func_name);
    if (!orig_func) {
        LOGW("Failed to find symbol: %s", func_name);
        return nullptr;
    }
    
    // 获取当前模块的 link_map
    struct link_map* lmap = get_link_map();
    if (!lmap) return nullptr;
    
    // 遍历动态节，找到 RELA 节
    ElfW(Rela)* rela = nullptr;
    ElfW(Dyn)* dyn = (ElfW(Dyn)*)lmap->l_ld;
    ElfW(Xword)* plt_got = nullptr;
    
    while (dyn->d_tag != DT_NULL) {
        if (dyn->d_tag == DT_JMPREL) {
            rela = (ElfW(Rela)*)dyn->d_un.d_ptr;
        } else if (dyn->d_tag == DT_PLTGOT) {
            plt_got = (ElfW(Xword)*)dyn->d_un.d_ptr;
        } else if (dyn->d_tag == DT_PLTREL) {
            if (dyn->d_un.d_val != DT_RELA) {
                LOGW("Unexpected PLT relocation type: %lu", (unsigned long)dyn->d_un.d_val);
                return nullptr;
            }
        } else if (dyn->d_tag == DT_RELACOUNT) {
            // Bionic 使用这个来确定 GOT 条目的数量
        }
        dyn++;
    }
    
    if (!rela || !plt_got) {
        LOGW("Failed to find RELA/PLTGOT for %s", func_name);
        return nullptr;
    }
    
    // 计算目标函数在 GOT 中的索引
    // 对于 ARM64，plt_got[0] 和 plt_got[1] 是保留的，plt_got[2] 开始是函数地址
    // 我们需要找到 orig_func 对应的索引
    
    // 方法：计算 (orig_func - &plt_got[2]) 然后除以条目大小？
    // 实际上，GOT 条目的顺序与 JMPREL 中的 relocation 顺序一致
    
    // 更简单的方法：遍历 RELA 表，找到对应符号的 relocation
    // 但这需要解析符号表，比较复杂
    
    // 使用暴力搜索：在 GOT 表中搜索 orig_func 的地址
    // GOT 表通常不会太大
    ElfW(Xword)* got_entry = nullptr;
    size_t got_size = 0;
    
    // 估算 GOT 大小（从 DT_RELACOUNT 或直接搜索）
    // 这里使用一个较大的搜索范围
    for (size_t i = 2; i < 512; i++) {
        if (plt_got[i] == (ElfW(Xword))orig_func) {
            got_entry = &plt_got[i];
            break;
        }
    }
    
    if (!got_entry) {
        LOGW("Failed to find GOT entry for %s (addr: %p)", func_name, orig_func);
        return nullptr;
    }
    
    return (void**)got_entry;
}

// 通用的 GOT 劫持模板
template<typename FuncType>
static bool hook_got(const char* func_name, FuncType hook_func, FuncType* orig_func_out) {
    void** got_entry = find_got_entry(func_name);
    if (!got_entry) return false;
    
    // 保存原始函数地址
    *orig_func_out = (FuncType)*got_entry;
    
    // 修改 GOT 条目
    // 注意：需要确保内存可写
    void* page = (void*)((uint64_t)got_entry & ~(PAGE_SIZE - 1));
    if (mprotect(page, PAGE_SIZE, PROT_READ | PROT_WRITE) != 0) {
        LOGE("Failed to mprotect GOT page for %s: %s", func_name, strerror(errno));
        return false;
    }
    
    *got_entry = (void*)hook_func;
    
    // 恢复内存保护
    mprotect(page, PAGE_SIZE, PROT_READ);
    
    LOGI("Successfully hooked %s via GOT", func_name);
    return true;
}

// ==================== 函数声明 ====================

// libc 函数类型定义
typedef int (*open_t)(const char* pathname, int flags, ...);
typedef int (*openat_t)(int dirfd, const char* pathname, int flags, ...);
typedef ssize_t (*read_t)(int fd, void* buf, size_t count);
typedef ssize_t (*pread_t)(int fd, void* buf, size_t count, off_t offset);
typedef ssize_t (*pread64_t)(int fd, void* buf, size_t count, off_t offset);
typedef FILE* (*fopen_t)(const char* pathname, const char* mode);
typedef size_t (*fread_t)(void* ptr, size_t size, size_t nmemb, FILE* stream);
typedef size_t (*fwrite_t)(const void* ptr, size_t size, size_t nmemb, FILE* stream);
typedef char* (*fgets_t)(char* str, int size, FILE* stream);
typedef int (*fclose_t)(FILE* fp);
typedef int (*__system_property_get_t)(const char* name, char* value);
typedef int (*stat_t)(const char* pathname, struct stat* statbuf);
typedef int (*fstat_t)(int fd, struct stat* statbuf);
typedef int (*lstat_t)(const char* pathname, struct stat* statbuf);
typedef ssize_t (*readlink_t)(const char* pathname, char* buf, size_t bufsiz);
typedef int (*access_t)(const char* pathname, int mode);

// 原始函数指针
static open_t original_open = nullptr;
static openat_t original_openat = nullptr;
static read_t original_read = nullptr;
static pread_t original_pread = nullptr;
static pread64_t original_pread64 = nullptr;
static fopen_t original_fopen = nullptr;
static fread_t original_fread = nullptr;
static fwrite_t original_fwrite = nullptr;
static fgets_t original_fgets = nullptr;
static fclose_t original_fclose = nullptr;
static __system_property_get_t original_system_property_get = nullptr;
static stat_t original_stat = nullptr;
static fstat_t original_fstat = nullptr;
static lstat_t original_lstat = nullptr;
static readlink_t original_readlink = nullptr;
static access_t original_access = nullptr;

// 互斥锁，用于线程安全
static std::mutex hook_mutex;
static std::atomic<bool> initialized{false};

// ==================== Hook 函数实现 ====================

// Hook: open
static int hooked_open(const char* pathname, int flags, ...) {
    if (!pathname) return original_open(pathname, flags);
    
    std::string path = pathname;
    if (is_spoofed_path(path)) {
        LOGD("Intercepted open: %s", pathname);
        // 对于只读文件，我们可以打开 /dev/null 或返回一个伪造的 fd
        // 但为了兼容性，我们仍然打开真实文件，在 read 时拦截
        // 对于某些特定文件，可以返回特殊 fd
            // 对于所有伪装文件，返回 /dev/null fd，在 read 时返回伪装数据
            int fd = original_open("/dev/null", O_RDONLY);
            if (fd >= 0) {
                {
                    std::lock_guard<std::mutex> lock(fd_map_mutex);
                    fd_path_map[fd] = path;
                }
                return fd;
            }
    }
    
    mode_t mode = 0;
    if (flags & O_CREAT) {
        va_list args;
        va_start(args, flags);
        mode = (mode_t)va_arg(args, int);
        va_end(args);
        return original_open(pathname, flags, mode);
    }
    return original_open(pathname, flags);
}

// Hook: openat
static int hooked_openat(int dirfd, const char* pathname, int flags, ...) {
    if (!pathname) return original_openat(dirfd, pathname, flags);
    
    std::string path = pathname;
    if (is_spoofed_path(path)) {
        LOGD("Intercepted openat: %s", pathname);
            // 对于所有伪装文件，返回 /dev/null fd
            int fd = original_openat(dirfd, "/dev/null", O_RDONLY);
            if (fd >= 0) {
                {
                    std::lock_guard<std::mutex> lock(fd_map_mutex);
                    fd_path_map[fd] = path;
                }
                return fd;
            }
    }
    
    mode_t mode = 0;
    if (flags & O_CREAT) {
        va_list args;
        va_start(args, flags);
        mode = (mode_t)va_arg(args, int);
        va_end(args);
        return original_openat(dirfd, pathname, flags, mode);
    }
    return original_openat(dirfd, pathname, flags);
}

// Hook: read
// 为 read 等函数维护一个 fd 到路径的映射（简化版）
static std::map<int, std::string> fd_path_map;
static std::mutex fd_map_mutex;

// 改进的 read hook
static ssize_t hooked_read(int fd, void* buf, size_t count) {
    // 检查是否是伪装的 fd
    {
        std::lock_guard<std::mutex> lock(fd_map_mutex);
        auto it = fd_path_map.find(fd);
        if (it != fd_path_map.end() && is_spoofed_path(it->second)) {
            std::string content = get_spoofed_content(it->second);
            if (!content.empty()) {
                size_t to_copy = std::min(count, content.size());
                memcpy(buf, content.data(), to_copy);
                LOGD("Returned spoofed content for %s (size: %zu)", it->second.c_str(), to_copy);
                return to_copy;
            }
        }
    }
    
    ssize_t ret = original_read(fd, buf, count);
    return ret;
}

// Hook: pread
static ssize_t hooked_pread(int fd, void* buf, size_t count, off_t offset) {
    ssize_t ret = original_pread(fd, buf, count, offset);
    if (ret <= 0) return ret;
    
    // 检查 fd 路径
    {
        std::lock_guard<std::mutex> lock(fd_map_mutex);
        auto it = fd_path_map.find(fd);
        if (it != fd_path_map.end() && is_spoofed_path(it->second)) {
            std::string content = get_spoofed_content(it->second);
            if (!content.empty()) {
                size_t to_copy = std::min((size_t)ret, std::min(count, content.size() - (size_t)offset));
                if (to_copy > 0 && offset < content.size()) {
                    memcpy(buf, content.data() + offset, to_copy);
                    return to_copy;
                }
                return 0;
            }
        }
    }
    
    return ret;
}

// Hook: fopen
static FILE* hooked_fopen(const char* pathname, const char* mode) {
    if (!pathname) return original_fopen(pathname, mode);
    
    std::string path = pathname;
    if (is_spoofed_path(path)) {
        LOGD("Intercepted fopen: %s, mode: %s", pathname, mode);
        
        // 对于只读模式，我们可以使用 fmemopen 或返回一个自定义的 FILE*
        // 但最简单的方法是打开 /dev/null，然后在 fread 时拦截
        // 或者使用 tmpfile() 并写入伪装内容
        
        // 使用 tmpfile 创建一个内存文件
        if (mode[0] == 'r') {
            std::string content = get_spoofed_content(path);
            if (!content.empty()) {
                // 创建临时文件并写入内容
                // 使用 tmpfile() 创建自动删除的临时文件
                FILE* fp = tmpfile();
                if (fp) {
                    fwrite(content.data(), 1, content.size(), fp);
                    rewind(fp);
                    {
                        std::lock_guard<std::mutex> lock(fd_map_mutex);
                        fd_path_map[fileno(fp)] = path;
                    }
                    return fp;
                }
            }
        }
    }
    
    return original_fopen(pathname, mode);
}

// Hook: fread
static size_t hooked_fread(void* ptr, size_t size, size_t nmemb, FILE* stream) {
    // 检查 stream 是否对应伪装文件
    int fd = fileno(stream);
    {
        std::lock_guard<std::mutex> lock(fd_map_mutex);
        auto it = fd_path_map.find(fd);
        if (it != fd_path_map.end() && is_spoofed_path(it->second)) {
            std::string content = get_spoofed_content(it->second);
            if (!content.empty()) {
                size_t total = size * nmemb;
                // 获取当前位置
                long pos = ftell(stream);
                if (pos < 0 || (size_t)pos >= content.size()) {
                    return 0;
                }
                size_t remaining = content.size() - (size_t)pos;
                size_t to_copy = std::min(total, remaining);
                memcpy(ptr, content.data() + pos, to_copy);
                fseek(stream, to_copy, SEEK_CUR);
                return to_copy / size;
            }
        }
    }
    
    return original_fread(ptr, size, nmemb, stream);
}

// Hook: fgets
static char* hooked_fgets(char* str, int size, FILE* stream) {
    int fd = fileno(stream);
    {
        std::lock_guard<std::mutex> lock(fd_map_mutex);
        auto it = fd_path_map.find(fd);
        if (it != fd_path_map.end() && is_spoofed_path(it->second)) {
            std::string content = get_spoofed_content(it->second);
            if (!content.empty()) {
                long pos = ftell(stream);
                if (pos < 0 || (size_t)pos >= content.size()) {
                    return nullptr;
                }
                size_t remaining = content.size() - (size_t)pos;
                size_t to_copy = std::min((size_t)(size - 1), remaining);
                memcpy(str, content.data() + pos, to_copy);
                str[to_copy] = '\0';
                fseek(stream, to_copy, SEEK_CUR);
                return str;
            }
        }
    }
    
    return original_fgets(str, size, stream);
}

// Hook: __system_property_get
static int hooked_system_property_get(const char* name, char* value) {
    // 首先检查是否是需要伪装的属性
    static std::mutex prop_mutex;
    static std::string current_name;
    static char current_value[PROP_VALUE_MAX];
    
    // 线程局部存储以避免递归
    __thread bool in_hook = false;
    
    if (in_hook) {
        return original_system_property_get(name, value);
    }
    
    // 检查属性名
    auto it = SPOOFED_PROPS.find(name);
    if (it != SPOOFED_PROPS.end()) {
        strncpy(value, it->second.c_str(), PROP_VALUE_MAX - 1);
        value[PROP_VALUE_MAX - 1] = '\0';
        LOGD("Returned spoofed property: %s = %s", name, value);
        return it->second.size();
    }
    
    // 对于列表类属性，需要处理 ro.product.cpu.abilist 的变体
    if (strcmp(name, "ro.product.cpu.abilist") == 0) {
        strcpy(value, "arm64-v8a,armeabi-v7a,armeabi");
        return strlen(value);
    }
    if (strcmp(name, "ro.product.cpu.abilist32") == 0) {
        strcpy(value, "armeabi-v7a,armeabi");
        return strlen(value);
    }
    if (strcmp(name, "ro.product.cpu.abilist64") == 0) {
        strcpy(value, "arm64-v8a");
        return strlen(value);
    }
    
    // 调用原始函数
    in_hook = true;
    int ret = original_system_property_get(name, value);
    in_hook = false;
    
    return ret;
}

// Hook: stat
static int hooked_stat(const char* pathname, struct stat* statbuf) {
    if (!pathname) return original_stat(pathname, statbuf);
    
    std::string path = pathname;
    if (is_spoofed_path(path)) {
        if (path == "/proc/cpuinfo") {
            statbuf->st_size = strlen(SPOOFED_CPUINFO);
            statbuf->st_mode = S_IFREG | 0444;
            statbuf->st_uid = 0;
            statbuf->st_gid = 0;
            return 0;
        }
        // 对于其他伪装文件，返回合理的默认大小
        statbuf->st_size = 256;
        statbuf->st_mode = S_IFREG | 0444;
        statbuf->st_uid = 0;
        statbuf->st_gid = 0;
        return 0;
    }
    
    return original_stat(pathname, statbuf);
}

// Hook: access
static int hooked_access(const char* pathname, int mode) {
    if (!pathname) return original_access(pathname, mode);
    
    std::string path = pathname;
    if (is_spoofed_path(path)) {
        return 0; // 总是返回存在
    }
    
    return original_access(pathname, mode);
}


// Hook: fclose
static int hooked_fclose(FILE* fp) {
    if (!fp) return original_fclose(fp);
    
    // 从映射中移除
    {
        std::lock_guard<std::mutex> lock(fd_map_mutex);
        int fd = fileno(fp);
        fd_path_map.erase(fd);
    }
    
    return original_fclose(fp);
}

// Hook: fstat
static int hooked_fstat(int fd, struct stat* statbuf) {
    // 检查是否是伪装的 fd
    {
        std::lock_guard<std::mutex> lock(fd_map_mutex);
        auto it = fd_path_map.find(fd);
        if (it != fd_path_map.end() && is_spoofed_path(it->second)) {
            if (it->second == "/proc/cpuinfo") {
                statbuf->st_size = strlen(SPOOFED_CPUINFO);
                statbuf->st_mode = S_IFREG | 0444;
                statbuf->st_uid = 0;
                statbuf->st_gid = 0;
                statbuf->st_blksize = 4096;
                statbuf->st_blocks = (strlen(SPOOFED_CPUINFO) + 511) / 512;
                return 0;
            }
            if (it->second == "/sys/devices/system/cpu/present" ||
                it->second == "/sys/devices/system/cpu/online") {
                statbuf->st_size = 4;
                statbuf->st_mode = S_IFREG | 0444;
                statbuf->st_uid = 0;
                statbuf->st_gid = 0;
                return 0;
            }
        }
    }
    
    return original_fstat(fd, statbuf);
}

// Hook: lstat
static int hooked_lstat(const char* pathname, struct stat* statbuf) {
    if (!pathname) return original_lstat(pathname, statbuf);
    
    std::string path = pathname;
    if (is_spoofed_path(path) && path == "/proc/cpuinfo") {
        statbuf->st_size = strlen(SPOOFED_CPUINFO);
        statbuf->st_mode = S_IFREG | 0444;
        statbuf->st_uid = 0;
        statbuf->st_gid = 0;
        return 0;
    }
    
    return original_lstat(pathname, statbuf);
}
// ==================== 初始化 ====================

static void init_hooks() {
    if (initialized.load()) return;
    
    std::lock_guard<std::mutex> lock(hook_mutex);
    if (initialized.load()) return;
    
    LOGI("Initializing CPU Info Spoofer hooks...");
    
    bool all_hooked = true;
    
    // 尝试 GOT 劫持所有目标函数
    // 注意：GOT 劫持可能因 Bionic 版本而异，这里使用 try-catch 风格处理
    
    #define TRY_HOOK_GOT(name, type, var) \
        do { \
            if (!hook_got<type>(#name, (type)hooked_##name, &var)) { \
                LOGW("GOT hook failed for " #name ", trying inline hook fallback"); \
                all_hooked = false; \
            } \
        } while(0)
    
    TRY_HOOK_GOT(open, open_t, original_open);
    TRY_HOOK_GOT(openat, openat_t, original_openat);
    TRY_HOOK_GOT(read, read_t, original_read);
    TRY_HOOK_GOT(pread, pread_t, original_pread);
    TRY_HOOK_GOT(fopen, fopen_t, original_fopen);
    TRY_HOOK_GOT(fread, fread_t, original_fread);
    TRY_HOOK_GOT(fgets, fgets_t, original_fgets);
    TRY_HOOK_GOT(fclose, fclose_t, original_fclose);
    TRY_HOOK_GOT(fstat, fstat_t, original_fstat);
    TRY_HOOK_GOT(lstat, lstat_t, original_lstat);
    TRY_HOOK_GOT(__system_property_get, __system_property_get_t, original_system_property_get);
    TRY_HOOK_GOT(stat, stat_t, original_stat);
    TRY_HOOK_GOT(access, access_t, original_access);
    
    #undef TRY_HOOK_GOT
    
    if (!all_hooked) {
        LOGW("Some hooks failed, functionality may be limited");
    }
    
    initialized.store(true);
    LOGI("CPU Info Spoofer hooks initialized successfully");
}

// ==================== Zygisk 入口 ====================

// Zygisk 模块入口函数（Zygisk 1.4.5+）
extern "C" __attribute__((visibility("default"))) void zygisk_module_entry(void* handle, uint32_t flags) {
    LOGI("Zygisk module entry called, flags: %u", flags);
    
    // flags & 1 表示在 Zygote 进程中
    if (flags & 1) {
        // 延迟初始化，确保 libc 已完全加载
        std::thread([]() {
            usleep(500000); // 延迟 500ms
            init_hooks();
        }).detach();
    }
}

// 兼容性：JNI_OnLoad（某些旧版本 Zygisk 或作为 JNI 库加载）
extern "C" JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void* reserved) {
    LOGI("JNI_OnLoad called");
    init_hooks();
    return JNI_VERSION_1_6;
}

// 全局构造函数（备用初始化）
__attribute__((constructor)) static void on_library_load() {
    LOGI("Library loaded via constructor");
    // 不要立即初始化，等待 Zygisk 调用或 JNI_OnLoad
    // 因为此时 libc 可能还没有完全初始化
}

// ==================== 导出原始函数（用于调试） ====================

extern "C" __attribute__((visibility("default"))) void* get_original_open() {
    return (void*)original_open;
}

extern "C" __attribute__((visibility("default"))) void* get_original_system_property_get() {
    return (void*)original_system_property_get;
}