#!/bin/bash
# 构建脚本 for CPU Info Spoofer
# 需要 Android NDK r21 或更高版本

set -e

NDK_PATH="${1:-$ANDROID_NDK_HOME}"
if [ -z "$NDK_PATH" ] || [ ! -d "$NDK_PATH" ]; then
    echo "Error: Android NDK path not found."
    echo "Usage: $0 <path-to-ndk>"
    echo "Or set ANDROID_NDK_HOME environment variable"
    exit 1
fi

echo "Using NDK: $NDK_PATH"

# 清理旧的构建
rm -rf libs obj

# 创建构建目录
mkdir -p libs/arm64-v8a

# 使用 ndk-build 构建
"$NDK_PATH/ndk-build" \
    NDK_PROJECT_PATH=. \
    APP_BUILD_SCRIPT=Android.mk \
    NDK_APPLICATION_MK=Application.mk \
    -j$(nproc)

# 检查输出
if [ -f "libs/arm64-v8a/libcpuinfo_spoofer.so" ]; then
    echo ""
    echo "Build successful!"
    echo "Output: libs/arm64-v8a/libcpuinfo_spoofer.so"
    echo ""
    echo "Next steps:"
    echo "1. Copy libs/arm64-v8a/libcpuinfo_spoofer.so to module/zygisk/arm64-v8a/"
    echo "2. Zip the module and flash via Magisk"
else
    echo "Build failed!"
    exit 1
fi