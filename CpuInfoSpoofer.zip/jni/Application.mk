APP_ABI := arm64-v8a
APP_PLATFORM := android-21
APP_STL := c++_static
APP_CPPFLAGS := -std=c++11 -Wall -Wextra -fvisibility=hidden
APP_LDFLAGS := -Wl,--hash-style=both
NDK_TOOLCHAIN_VERSION := clang