#!/system/bin/sh
# CPU Info Spoofer - Service Script
# 后台服务，用于持续监控和修复

MODDIR="${0%/*}"
LOG_TAG="CpuInfoSpoofer"

log_tag="$LOG_TAG" log_write() {
    echo "[$LOG_TAG] $1" >> /data/local/tmp/cpuinfo_spoofer.log 2>/dev/null
    log -t "$LOG_TAG" "$1" 2>/dev/null
}

log_write "Service started, monitoring..."

# 循环检查，防止某些应用通过特殊手段绕过hook
while true; do
    sleep 30
    
    # 检查关键属性是否被篡改（通过getprop命令，但我们的hook会拦截）
    # 这里只是做日志记录
    CURRENT_ABI=$(getprop ro.product.cpu.abi 2>/dev/null)
    if [ "$CURRENT_ABI" != "arm64-v8a" ] && [ -n "$CURRENT_ABI" ]; then
        log_write "Detected ABI change: $CURRENT_ABI, attempting fix..."
        resetprop ro.product.cpu.abi arm64-v8a 2>/dev/null
    fi
done