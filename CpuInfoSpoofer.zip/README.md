# CPU Info Spoofer - Zygisk 模块

基于 Zygisk 的 CPU 信息全面伪装模块，使用 Native Inline Hook 技术劫持文件读取和属性获取，伪装为 **HiSilicon Kirin 9000S** 处理器。

## 特性

- **全面伪装**：覆盖 `/proc/cpuinfo`、`/sys/devices/system/cpu/*`、系统属性等
- **GOT 劫持**：使用 ARM64 GOT (Global Offset Table) 劫持技术，稳定且高效
- **进程级注入**：通过 Zygisk 注入到所有应用进程和系统进程
- **开机自启**：配合 Magisk 的 post-fs-data 和 service 脚本实现开机自动激活
- **检测规避**：多层防护，包括：
  - 文件读取拦截 (`open`, `read`, `pread`, `fopen`, `fread`, `fgets`)
  - 文件状态拦截 (`stat`, `fstat`, `lstat`, `access`)
  - 属性获取拦截 (`__system_property_get`)

## 伪装信息

### /proc/cpuinfo
```
Processor       : AArch64 Processor rev 0 (aarch64)
Features        : fp asimd evtstrm aes pmull sha1 sha2 crc32 atomics fphp asimdhp
CPU implementer : 0x48
CPU architecture: 8
CPU variant     : 0x1
CPU part        : 0xd0c
CPU revision    : 0

processor       : 0
BogoMIPS        : 26.00
CPU implementer : 0x48
CPU architecture: 8
CPU variant     : 0x1
CPU part        : 0xd0c
CPU revision    : 0

processor       : 1-3  (Big cores, variant 0x2, part 0xd0a)
processor       : 4-7  (Little cores, variant 0x3, part 0xd0b)

Hardware        : HiSilicon Kirin 9000S
```

### 系统属性
- `ro.product.cpu.abi` → `arm64-v8a`
- `ro.product.cpu.abilist` → `arm64-v8a,armeabi-v7a,armeabi`
- `ro.hardware` → `chagall`
- `ro.soc.model` → `kirin9000s`
- `ro.chipname` → `kirin9000s`

### CPU 频率
- 超大核 (cpu0): Max 2.8GHz, Min 480MHz
- 大核 (cpu4): Max 2.52GHz
- 小核 (cpu7): Max 2.048GHz

## 安装步骤

### 1. 环境准备

确保你已经安装了：
- Android NDK r21 或更高版本
- Magisk 24.0+ (支持 Zygisk 1.4.5)

设置环境变量：
```bash
export ANDROID_NDK_HOME=/path/to/android-ndk
```

### 2. 编译 Native 库

```bash
cd CpuInfoSpoofer/jni
chmod +x build.sh
./build.sh $ANDROID_NDK_HOME
```

如果编译成功，会在 `libs/arm64-v8a/` 目录下生成 `libcpuinfo_spoofer.so`。

### 3. 安装模块

```bash
# 将编译好的库复制到模块目录
cp libs/arm64-v8a/libcpuinfo_spoofer.so CpuInfoSpoofer/zygisk/arm64-v8a/

# 打包模块
cd CpuInfoSpoofer
zip -r ../cpuinfo_spoofer.zip *

# 使用 Magisk Manager 刷入 ../cpuinfo_spoofer.zip
```

或者在 Magisk Manager 中直接选择模块目录进行本地安装。

### 4. 启用 Zygisk

1. 打开 Magisk Manager
2. 进入 **设置** → **Zygisk**
3. 启用 **Zygisk**
4. （可选）在 **应用程序** 中配置排除列表

### 5. 重启设备

重启后模块将自动激活。

## 验证伪装效果

### 方法 1: 使用终端
```bash
# 查看 CPU 信息
cat /proc/cpuinfo

# 查看 CPU 数量
cat /sys/devices/system/cpu/present
cat /sys/devices/system/cpu/online

# 查看 CPU 频率
cat /sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq

# 查看属性
getprop ro.product.cpu.abi
getprop ro.hardware
getprop ro.soc.model
```

### 方法 2: 使用 CPU-Z 应用
下载 CPU-Z for Android，查看 Processor 信息，应该显示：
- **Cores**: 8
- **Architecture**: ARMv8
- **Processor**: AArch64 Processor rev 0 (aarch64)
- **Hardware**: HiSilicon Kirin 9000S

### 方法 3: 查看日志
```bash
cat /data/local/tmp/cpuinfo_spoofer.log
```

## 自定义伪装信息

编辑 `post-fs-data.sh` 中的伪装数据，或直接修改 `jni/main.cpp` 中的 `SPOOFED_*` 常量后重新编译。

### 修改 CPU 型号
在 `main.cpp` 中修改以下内容：
```cpp
// 修改 Hardware 字段
static const char* SPOOFED_CPUINFO = R"(...Hardware        : Your Custom CPU...)";

// 修改系统属性
static const std::map<std::string, std::string> SPOOFED_PROPS = {
    {"ro.hardware", "your_hardware"},
    {"ro.soc.model", "your_model"},
};
```

### 修改 CPU 核心数
```cpp
static const char* SPOOFED_CPU_PRESENT = "0-3";  // 4 核
static const char* SPOOFED_CPU_ONLINE = "0-3";
```

### 修改 CPU 频率
```cpp
static const char* SPOOFED_FREQ_MAX = "2600000";   // 2.6 GHz
static const char* SPOOFED_FREQ_MIN = "300000";    // 300 MHz
```

## 技术原理

### GOT 劫持 (Global Offset Table Hijacking)

本模块主要使用 GOT 劫持技术，相比传统的 Inline Hook 更稳定：

1. **定位目标函数**：通过 `dlsym(RTLD_NEXT, "open")` 获取原始函数地址
2. **解析 GOT 表**：遍历动态节的 `DT_PLTGOT` 和 `DT_JMPREL`，找到对应函数的 GOT 条目
3. **修改 GOT 条目**：将 GOT 条目指向我们的 Hook 函数
4. **内存保护切换**：使用 `mprotect` 临时修改内存保护，完成修改后恢复

### 拦截的文件操作

| 函数 | 作用 |
|------|------|
| `open`, `openat` | 拦截文件打开，对伪装文件返回 `/dev/null` fd |
| `read`, `pread` | 拦截文件读取，返回伪装数据 |
| `fopen`, `fread`, `fgets` | 拦截 stdio 操作，返回临时文件中的伪装数据 |
| `stat`, `fstat`, `lstat` | 拦截文件状态查询，返回伪装文件的大小和属性 |
| `access` | 拦截文件存在性检查，伪装文件总是返回存在 |
| `__system_property_get` | 拦截属性获取，返回伪装的属性值 |

### 数据流

```
应用调用 open("/proc/cpuinfo", O_RDONLY)
    ↓ hooked_open
返回 /dev/null fd (并记录映射)
    ↓
应用调用 read(fd, buf, size)
    ↓ hooked_read
检查 fd_path_map → 发现是伪装文件
返回 SPOOFED_CPUINFO 数据
```

## 故障排查

### 模块未生效
1. 确认 Zygisk 已启用：Magisk 设置 → Zygisk → 开启
2. 查看日志：`cat /data/local/tmp/cpuinfo_spoofer.log`
3. 确认模块已安装且没有禁用

### 某些应用仍能检测真实 CPU
1. 某些应用可能使用 Java 层的 `/proc` 读取（通过 FileInputStream），这些会被 hook 捕获
2. 某些应用可能直接读取内存中的属性缓存，需要重启应用
3. 某些系统工具（如 `top`、`cat /proc/cpuinfo`）在 shell 中运行，可能不受 Zygisk 影响，但 `post-fs-data.sh` 中的 `resetprop` 会修改全局属性

### 设备卡在开机动画
1. 某些 ROM 可能与 GOT 劫持冲突
2. 尝试在 Magisk 中禁用模块，进入安全模式
3. 可以修改 `post-fs-data.sh` 注释掉某些 resetprop 命令

### 日志不输出
```bash
# 确保目录存在
mkdir -p /data/local/tmp
chmod 755 /data/local/tmp

# 手动创建日志文件
touch /data/local/tmp/cpuinfo_spoofer.log
chmod 666 /data/local/tmp/cpuinfo_spoofer.log
```

## 已知限制

1. **Shell 环境**：在 adb shell 或终端模拟器中，`cat /proc/cpuinfo` 可能显示真实内容（因为 shell 进程可能不是 Zygote 衍生）。使用 `resetprop` 和 `post-fs-data.sh` 中的 mount 作为补充。
2. **性能影响**：所有文件读写和属性获取都会经过 hook，可能有轻微性能开销（通常 <1%）。
3. **部分系统进程**：某些系统守护进程在 Zygote 之前启动，可能不受影响。但大多数用户态应用都会经过 Zygote。
4. **检测绕过**：极少数应用可能通过读取内核内存或使用 ioctl 绕过本模块。

## 安全说明

- 本模块仅修改用户态可见的 CPU 信息
- 不会修改内核数据结构或 `/proc` 内核生成的实际数据
- 不会影响系统实际性能或调度
- 卸载模块后所有伪装将自动失效

## 开源与许可

本模块仅供学习交流使用。使用本模块造成的任何后果由使用者自行承担。

## 更新日志

### v1.0
- 初始版本
- 支持 ARM64 架构
- 伪装 Kirin 9000S 处理器信息
- 支持 Zygisk 1.4.5

## 常见问题

**Q: 为什么某些应用仍然能检测到真实 CPU？**  
A: 确保应用是在 Zygisk 启用后启动的。如果是系统应用或预装应用，可能需要清除数据后重启。

**Q: 会影响游戏性能吗？**  
A: 不会。本模块只修改信息返回，不修改 CPU 频率或调度策略。

**Q: 支持 x86 或 x86_64 设备吗？**  
A: 当前版本仅支持 ARM64 (arm64-v8a)。如需其他架构，需要修改汇编代码。

**Q: 如何卸载？**  
A: 在 Magisk Manager 中卸载模块，然后重启设备。所有修改将自动还原。