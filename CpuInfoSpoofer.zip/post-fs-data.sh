#!/system/bin/sh
# CPU Info Spoofer - Post FS Data Script
# 开机时执行，用于验证模块加载和进行额外的系统级伪装

MODDIR="${0%/*}"
LOG_TAG="CpuInfoSpoofer"

log_tag="$LOG_TAG" log_write() {
    echo "[$LOG_TAG] $1" >> /data/local/tmp/cpuinfo_spoofer.log 2>/dev/null
    log -t "$LOG_TAG" "$1" 2>/dev/null
}

log_write "Module loaded, checking Zygisk..."

# 检查Zygisk是否启用
ZYGISK_STATUS=$(magisk --zygisk 2>/dev/null)
if [ "$ZYGISK_STATUS" != "enabled" ]; then
    log_write "WARNING: Zygisk is not enabled! Please enable it in Magisk settings."
fi

# 确保目录存在
mkdir -p /data/local/tmp
chmod 755 /data/local/tmp

# 挂载伪装的cpuinfo (作为fallback，主要依赖hook)
# 注意：这会在系统分区创建一个覆盖，但模块卸载时会自动清理
# 主要hook会处理应用层的读取，这里作为系统工具的后备
if [ ! -f /data/local/tmp/cpuinfo_spoofed ]; then
    cat << 'EOF' > /data/local/tmp/cpuinfo_spoofed
Processor       : AArch64 Processor rev 0 (aarch64)
Features        : fp asimd evtstrm aes pmull sha1 sha2 crc32 atomics fphp asimdhp
CPU implementer : 0x48
CPU architecture: 8
CPU variant     : 0x1
CPU part        : 0xd0c
CPU revision    : 0

processor       : 0
BogoMIPS        : 26.00
CPU implementer : 0x48
CPU architecture: 8
CPU variant     : 0x1
CPU part        : 0xd0c
CPU revision    : 0

processor       : 1
BogoMIPS        : 26.00
CPU implementer : 0x48
CPU architecture: 8
CPU variant     : 0x2
CPU part        : 0xd0a
CPU revision    : 0

processor       : 2
BogoMIPS        : 26.00
CPU implementer : 0x48
CPU architecture: 8
CPU variant     : 0x2
CPU part        : 0xd0a
CPU revision    : 0

processor       : 3
BogoMIPS        : 26.00
CPU implementer : 0x48
CPU architecture: 8
CPU variant     : 0x2
CPU part        : 0xd0a
CPU revision    : 0

processor       : 4
BogoMIPS        : 26.00
CPU implementer : 0x48
CPU architecture: 8
CPU variant     : 0x3
CPU part        : 0xd0b
CPU revision    : 0

processor       : 5
BogoMIPS        : 26.00
CPU implementer : 0x48
CPU architecture: 8
CPU variant     : 0x3
CPU part        : 0xd0b
CPU revision    : 0

processor       : 6
BogoMIPS        : 26.00
CPU implementer : 0x48
CPU architecture: 8
CPU variant     : 0x3
CPU part        : 0xd0b
CPU revision    : 0

processor       : 7
BogoMIPS        : 26.00
CPU implementer : 0x48
CPU architecture: 8
CPU variant     : 0x3
CPU part        : 0xd0b
CPU revision    : 0

Hardware        : HiSilicon Kirin 9000S
EOF
fi

# 使用 magisk 的 resetprop 修改关键属性（如果可用）
# 注意：这些属性修改是系统级的，但应用通常通过 libc 或 Java API 读取
# 我们的 native hook 会拦截这些读取，这里作为额外层
resetprop ro.product.cpu.abi arm64-v8a 2>/dev/null
resetprop ro.product.cpu.abilist arm64-v8a,armeabi-v7a,armeabi 2>/dev/null
resetprop ro.product.cpu.abilist32 armeabi-v7a,armeabi 2>/dev/null
resetprop ro.product.cpu.abilist64 arm64-v8a 2>/dev/null
resetprop ro.hardware chagall 2>/dev/null
resetprop ro.hardware.chipname kirin9000s 2>/dev/null
resetprop ro.soc.model kirin9000s 2>/dev/null

log_write "Post-fs-data script completed"