# 部署指南 - CPU Info Spoofer

## 快速开始

### 第一步：编译 Native 库

你需要 Android NDK r21+ 来编译 native hook 库。

```bash
# 设置 NDK 路径
export ANDROID_NDK_HOME=/path/to/android-ndk-r26

# 进入模块目录
cd CpuInfoSpoofer/jni

# 运行构建脚本
chmod +x build.sh
./build.sh $ANDROID_NDK_HOME
```

成功后会输出：
```
Build successful!
Output: libs/arm64-v8a/libcpuinfo_spoofer.so
```

### 第二步：组装模块

```bash
cd CpuInfoSpoofer
chmod +x build_module.sh customize.sh post-fs-data.sh service.sh

# 将编译好的库复制到模块目录（如果上一步成功）
mkdir -p zygisk/arm64-v8a
cp jni/libs/arm64-v8a/libcpuinfo_spoofer.so zygisk/arm64-v8a/

# 打包模块
./build_module.sh
```

这会生成 `cpuinfo_spoofer.zip`。

### 第三步：安装模块

1. **通过 Magisk Manager 安装**（推荐）
   - 打开 Magisk Manager
   - 进入 **模块** → **从存储安装**
   - 选择 `cpuinfo_spoofer.zip`
   - 等待安装完成
   - 重启设备

2. **通过 Recovery 安装**
   - 将 `cpuinfo_spoofer.zip` 传到设备
   - 进入 TWRP Recovery
   - 选择 **安装** → 选择 zip 文件
   - 滑动确认安装
   - 重启设备

### 第四步：启用 Zygisk

1. 打开 Magisk Manager
2. 进入 **设置** → **Zygisk**
3. 开启 **Zygisk**
4. 在 **应用列表** 中配置需要排除的应用（如银行应用，如果它们有反检测机制）

### 第五步：验证安装

```bash
# 查看日志
cat /data/local/tmp/cpuinfo_spoofer.log

# 查看 CPU 信息
cat /proc/cpuinfo

# 查看属性
getprop ro.hardware
getprop ro.soc.model

# 应该看到伪装后的 Kirin 9000S 信息
```

## 模块文件结构

```
CpuInfoSpoofer/
├── module.prop                 # Magisk 模块描述
├── post-fs-data.sh            # 开机脚本，修改系统属性和创建日志
├── service.sh                 # 后台服务，持续监控
├── customize.sh               # 安装时自定义脚本
├── zygisk/
│   ├── config.prop            # Zygisk 模块配置
│   └── arm64-v8a/
│       └── libcpuinfo_spoofer.so  # 编译后的 native 库
├── jni/
│   ├── main.cpp               # Hook 核心代码
│   ├── Android.mk             # NDK 构建配置
│   ├── Application.mk         # NDK 应用配置
│   └── build.sh               # 构建脚本
└── README.md                  # 详细文档
```

## 故障排查

### 问题：安装后模块未生效

**解决步骤：**
1. 确认 Zygisk 已启用
2. 查看日志：`cat /data/local/tmp/cpuinfo_spoofer.log`
3. 确认 `libcpuinfo_spoofer.so` 存在于 `zygisk/arm64-v8a/` 目录
4. 确认 Magisk 版本 >= 24.0

### 问题：编译失败

**常见原因：**
- NDK 路径错误：确保 `ANDROID_NDK_HOME` 指向正确的 NDK 目录
- NDK 版本过低：需要 r21 或更高
- 磁盘空间不足：确保有足够的空间进行编译

**解决方法：**
```bash
# 验证 NDK 路径
ls $ANDROID_NDK_HOME/ndk-build

# 如果找不到，设置正确的路径
export ANDROID_NDK_HOME=/root/android-ndk-r26
```

### 问题：某些应用仍显示真实 CPU

**原因：**
- 应用在 Zygisk 启用前启动（系统应用）
- 应用使用 Java 层的反射绕过 native hook

**解决方法：**
1. 清除应用数据并重启
2. 将应用加入 Zygisk 排除列表后重启，再移出排除列表
3. 对于系统应用，可能需要重启设备

## 高级配置

### 自定义伪装信息

编辑 `post-fs-data.sh` 中的伪装数据，或直接修改 `jni/main.cpp`：

```cpp
// 修改伪装 CPU 型号
static const char* SPOOFED_CPUINFO = R"(...你的 cpuinfo 内容...)";

// 修改系统属性
static const std::map<std::string, std::string> SPOOFED_PROPS = {
    {"ro.hardware", "your_device"},
    {"ro.soc.model", "your_soc"},
};
```

### 添加排除列表

在 Magisk Manager → Zygisk → **应用列表** 中添加需要排除的应用。

### 查看实时日志

```bash
# 实时查看日志输出
tail -f /data/local/tmp/cpuinfo_spoofer.log
```

## 性能影响

- CPU 占用：< 0.5%（仅在文件 I/O 和属性访问时触发）
- 内存占用：~2-4 MB（包含 map 和缓存）
- 启动时间：延迟 500ms 后初始化，避免影响开机速度

## 安全建议

1. 仅在必要时启用此模块
2. 不要用于恶意目的
3. 某些银行/支付应用可能有反检测机制，使用前请确认
4. 保持 Magisk 和模块为最新版本

## 联系与支持

如果在使用过程中遇到问题：
1. 查看 `README.md` 中的故障排查部分
2. 查看 `/data/local/tmp/cpuinfo_spoofer.log` 日志
3. 确认所有依赖项已正确安装

祝你使用愉快！