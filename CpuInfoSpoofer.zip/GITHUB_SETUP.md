# GitHub Actions 自动编译指南

使用 GitHub Actions 在云端自动编译模块，**无需在本地安装 NDK**。

## 🚀 快速开始（5分钟）

### 第一步：创建 GitHub 仓库

1. 打开 https://github.com/new
2. 填写信息：
   - **Repository name**: `CpuInfoSpoofer`
   - **Description**: `CPU Info Spoofer Magisk Module`
   - 选择 **Private**（私有，推荐）或 **Public**（公开）
   - ✅ 勾选 **Add a README file**
3. 点击 **Create repository**

### 第二步：上传代码

在电脑上打开终端，执行：

```bash
# 1. 克隆空仓库
git clone https://github.com/你的用户名/CpuInfoSpoofer.git
cd CpuInfoSpoofer

# 2. 删除自动生成的 README.md（我们将用自己的）
rm README.md

# 3. 复制模块文件到仓库目录
# 把 /workspace/CpuInfoSpoofer/ 下的所有文件复制到这里

# 4. 提交并推送
git add .
git commit -m "Initial commit: CPU Info Spoofer module"
git push origin main
```

**或者更简单的方式：**

如果你在 macOS/Linux 上，可以直接在 `/workspace/CpuInfoSpoofer/` 目录执行：

```bash
cd /workspace/CpuInfoSpoofer
git init
git remote add origin https://github.com/你的用户名/CpuInfoSpoofer.git
git add .
git commit -m "Initial commit"
git branch -M main
git push -u origin main
```

### 第三步：等待自动编译

1. 打开你的 GitHub 仓库页面
2. 点击顶部 **Actions** 标签
3. 你会看到 **Build CPU Info Spoofer** 工作流正在运行
4. 等待 3-5 分钟，直到出现 ✅ 绿色对勾

### 第四步：下载编译好的模块

编译完成后，有两种方式获取：

**方式A：从 Releases 下载（推荐）**
1. 点击仓库顶部的 **Releases** 标签
2. 找到最新的 release（例如 `v1`）
3. 下载 `cpuinfo_spoofer.zip`
4. 传到手机安装

**方式B：从 Actions 下载**
1. 进入 **Actions** 页面
2. 点击最新的成功构建
3. 在页面底部找到 **Artifacts** 区域
4. 下载 `cpuinfo_spoofer_arm64-v8a.zip`
5. 解压得到 `cpuinfo_spoofer.zip`

### 第五步：安装模块

```bash
# 1. 把 cpuinfo_spoofer.zip 传到手机
# 2. 打开 Magisk Manager
# 3. 进入 模块 → 从存储安装
# 4. 选择 cpuinfo_spoofer.zip
# 5. 重启设备
```

## 🔄 更新模块

修改代码后重新编译：

```bash
# 1. 修改代码
# 2. 提交更改
git add .
git commit -m "Update: 修改伪装信息"
git push

# 3. GitHub Actions 会自动重新编译
# 4. 等待完成后下载新版本
```

## 📋 手动触发编译

如果你想用特定 NDK 版本编译：

1. 进入仓库的 **Actions** 页面
2. 左侧选择 **Build CPU Info Spoofer**
3. 点击 **Run workflow** 按钮
4. 选择 NDK 版本（默认 r26d）
5. 点击 **Run workflow**

## 📁 工作流说明

### 自动触发条件

以下情况会自动触发编译：
- 推送到 `main` 分支
- 修改了 `jni/`、`zygisk/`、`module.prop` 或 `.github/workflows/build.yml`
- 创建 Pull Request

### 编译流程

```
代码推送 → 下载 NDK → 编译 .so → 打包模块 → 上传 Artifact → 创建 Release
   ↓          (3-5分钟)
 等待完成    下载 zip → 安装到手机
```

### 编译输出

- **Artifact**: `cpuinfo_spoofer_arm64-v8a.zip`（保留30天）
- **Release**: 自动发布到 GitHub Releases（仅 main 分支）

## ❓ 常见问题

### Q: Actions 显示 "setup-ndk failed"？
A: 我已经改用手动下载 NDK 的方式，不依赖第三方 action，应该不会出现这个问题。

### Q: 编译失败怎么办？
A: 
1. 点击失败的构建查看日志
2. 展开 **Build native library** 步骤
3. 查看具体的编译错误
4. 常见问题：
   - 内存不足：GitHub 提供 7GB RAM，通常足够
   - NDK 下载慢：脚本会自动重试和切换镜像

### Q: 如何下载历史版本？
A: 在 **Actions** 中点击对应的构建，在 Artifacts 区域下载。

### Q: 免费版 GitHub 有 Actions 限制吗？
A: 免费版每月有 2000 分钟 Actions 额度，足够每月编译 400+ 次。

### Q: 私有仓库会泄露代码吗？
A: 不会。GitHub Actions 在云端运行，构建产物只有你能访问（除非公开 release）。

## 🔧 高级配置

### 修改编译配置

编辑 `.github/workflows/build.yml`：

```yaml
# 修改 NDK 版本
- name: Download NDK
  run: |
    NDK_VERSION="${{ github.event.inputs.ndk_version || 'r26d' }}"
    # 改为 r26b, r25b 等

# 添加更多架构
strategy:
  matrix:
    include:
      - abi: arm64-v8a
        arch: arm64
      # - abi: armeabi-v7a
      #   arch: arm
```

### 自动发布到其他平台

可以在工作流中添加步骤，自动发布到：
- Telegram Bot
- Discord Webhook
- 邮件通知

### 添加单元测试

```yaml
- name: Run tests
  run: |
    # 添加测试命令
    echo "No tests yet"
```

## 📊 查看构建状态

在仓库首页会显示 badges：

```markdown
![Build](https://github.com/你的用户名/CpuInfoSpoofer/actions/workflows/build.yml/badge.svg)
```

## 🔒 安全建议

1. **使用 Private 仓库**：避免代码公开
2. **不要泄露 Token**：GitHub Token 自动管理，无需手动配置
3. **审查 Actions**：只使用官方或可信的 actions
4. **定期更新**：保持 NDK 和工作流为最新版本

## 📞 需要帮助？

- 查看构建日志中的错误信息
- 检查 `/data/local/tmp/cpuinfo_spoofer.log`（设备上的日志）
- 确认 Zygisk 已启用
- 尝试重启设备和应用

---

## 完整命令参考

```bash
# 初始化仓库
git init
git remote add origin https://github.com/用户名/CpuInfoSpoofer.git
git add .
git commit -m "Initial commit"
git branch -M main
git push -u origin main

# 更新代码
git add .
git commit -m "Update message"
git push

# 查看状态
git status

# 查看远程地址
git remote -v
```

祝你使用愉快！🎉