#!/bin/bash
# Termux 一键编译脚本
# 此脚本会自动下载 NDK 并编译模块

set -e

echo "======================================"
echo "  CPU Info Spoofer - Termux Build"
echo "======================================"
echo ""

# 检查是否在 Termux 中运行
if [ ! -d "/data/data/com.termux" ]; then
    echo "警告: 此脚本设计为在 Termux 中运行"
    echo "如果不在 Termux 中，请确保已安装 Android NDK 并设置 ANDROID_NDK_HOME"
    read -p "是否继续? (y/N): " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
fi

# 配置
NDK_VERSION="r26d"
NDK_DIR="$HOME/android-ndk-$NDK_VERSION"
NDK_ZIP="android-ndk-${NDK_VERSION}-linux.zip"
NDK_URL="https://dl.google.com/android/repository/${NDK_ZIP}"

# 检查 NDK 是否已存在
if [ -d "$NDK_DIR" ]; then
    echo "✓ 找到已安装的 NDK: $NDK_DIR"
    export ANDROID_NDK_HOME="$NDK_DIR"
else
    echo "→ 未找到 NDK，开始下载..."
    
    # 下载 NDK
    if [ ! -f "$HOME/$NDK_ZIP" ]; then
        echo "正在下载 Android NDK $NDK_VERSION..."
        echo "这可能需要几分钟，请保持网络畅通..."
        
        # 尝试使用 wget 或 curl
        if command -v wget &> /dev/null; then
            wget -q --show-progress "$NDK_URL" -O "$HOME/$NDK_ZIP"
        elif command -v curl &> /dev/null; then
            curl -L --progress-bar "$NDK_URL" -o "$HOME/$NDK_ZIP"
        else
            echo "错误: 需要 wget 或 curl"
            exit 1
        fi
        
        echo "✓ 下载完成"
    else
        echo "✓ 找到已下载的 NDK 压缩包"
    fi
    
    # 解压 NDK
    echo "正在解压 NDK（这可能需要几分钟）..."
    cd "$HOME"
    unzip -q "$NDK_ZIP"
    
    if [ -d "$NDK_DIR" ]; then
        echo "✓ NDK 解压成功"
        export ANDROID_NDK_HOME="$NDK_DIR"
        
        # 可选：删除压缩包节省空间
        read -p "删除 NDK 压缩包以节省空间? (y/N): " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            rm "$HOME/$NDK_ZIP"
            echo "✓ 已删除压缩包"
        fi
    else
        echo "错误: NDK 解压失败"
        exit 1
    fi
fi

# 验证 NDK
if [ ! -f "$ANDROID_NDK_HOME/ndk-build" ]; then
    echo "错误: NDK 似乎不完整，缺少 ndk-build"
    exit 1
fi

echo ""
echo "======================================"
echo "  NDK 准备完成"
echo "  路径: $ANDROID_NDK_HOME"
echo "======================================"
echo ""

# 进入模块目录
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
MODULE_DIR="$SCRIPT_DIR"
JNI_DIR="$MODULE_DIR/jni"

echo "→ 模块目录: $MODULE_DIR"
echo "→ 编译目录: $JNI_DIR"
echo ""

cd "$JNI_DIR"

# 清理旧构建
echo "→ 清理旧构建..."
rm -rf libs obj

# 执行编译
echo "→ 开始编译..."
echo "  这可能需要 5-15 分钟，请耐心等待..."
echo ""

"$ANDROID_NDK_HOME/ndk-build" \
    NDK_PROJECT_PATH=. \
    APP_BUILD_SCRIPT=Android.mk \
    NDK_APPLICATION_MK=Application.mk \
    -j$(nproc) 2>&1 | tee "$MODULE_DIR/build.log"

echo ""
echo "======================================"

# 检查编译结果
if [ -f "libs/arm64-v8a/libcpuinfo_spoofer.so" ]; then
    echo "✓ 编译成功!"
    echo ""
    echo "输出文件:"
    ls -lh libs/arm64-v8a/libcpuinfo_spoofer.so
    echo ""
    echo "下一步:"
    echo "1. 将库文件复制到模块目录:"
    echo "   mkdir -p $MODULE_DIR/zygisk/arm64-v8a"
    echo "   cp libs/arm64-v8a/libcpuinfo_spoofer.so $MODULE_DIR/zygisk/arm64-v8a/"
    echo ""
    echo "2. 打包模块:"
    echo "   cd $MODULE_DIR"
    echo "   chmod +x build_module.sh"
    echo "   ./build_module.sh"
    echo ""
    echo "3. 安装到 Magisk"
    echo ""
    echo "详细日志已保存到: $MODULE_DIR/build.log"
else
    echo "✗ 编译失败!"
    echo ""
    echo "请检查上面的错误信息，或查看详细日志:"
    echo "  cat $MODULE_DIR/build.log"
    echo ""
    echo "常见问题:"
    echo "1. 内存不足: 尝试创建交换分区"
    echo "   dd if=/dev/zero of=/swapfile bs=1M count=2048"
    echo "   chmod 600 /swapfile"
    echo "   mkswap /swapfile"
    echo "   swapon /swapfile"
    echo ""
    echo "2. NDK 版本问题: 尝试使用其他 NDK 版本"
    exit 1
fi

echo "======================================"