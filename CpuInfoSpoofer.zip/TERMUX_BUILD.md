# Termux 编译指南

在 Android 手机上使用 Termux 编译本模块。

## 第一步：安装 Termux

从 F-Droid 下载安装 Termux（不要用 Google Play 的旧版本）：
https://f-droid.org/packages/com.termux/

## 第二步：安装依赖

打开 Termux，依次执行：

```bash
# 更新包管理器
pkg update -y

# 安装基础工具
pkg install -y git curl wget unzip

# 安装 NDK（推荐 ndk-r26）
pkg install -y ndk-multilib ndk-sysroot clang

# 或者下载特定版本 NDK
mkdir -p ~/ndk
cd ~/ndk
wget https://dl.google.com/android/repository/android-ndk-r26d-linux.zip
unzip android-ndk-r26d-linux.zip
export ANDROID_NDK_HOME=~/ndk/android-ndk-r26d
```

## 第三步：获取源代码

```bash
# 方式1：如果你已经通过文件管理器把文件传到手机
# 直接在 Termux 中进入目录
cd /sdcard/Download/CpuInfoSpoofer/jni

# 方式2：用 git 克隆（如果放在 GitHub 上）
# git clone <你的仓库地址>
# cd CpuInfoSpoofer/jni
```

## 第四步：编译

```bash
cd ~/ndk
export NDK=~/ndk/android-ndk-r26d
cd CpuInfoSpoofer/jni

# 设置 NDK 路径（根据你实际的 NDK 路径调整）
export ANDROID_NDK_HOME=~/ndk/android-ndk-r26d

# 运行构建脚本
chmod +x build.sh
./build.sh $ANDROID_NDK_HOME
```

## 第五步：如果编译成功

```bash
# 查看输出
ls -la libs/arm64-v8a/

# 将 .so 文件复制到模块目录
mkdir -p ../zygisk/arm64-v8a
cp libs/arm64-v8a/libcpuinfo_spoofer.so ../zygisk/arm64-v8a/

# 返回模块根目录打包
cd ..
chmod +x build_module.sh
./build_module.sh
```

## 常见问题

### Q1: `pkg install ndk-multilib` 报错
某些 Termux 版本可能没有 ndk 包。可以手动下载：

```bash
cd ~
wget https://dl.google.com/android/repository/android-ndk-r26d-linux.zip
unzip android-ndk-r26d-linux.zip
export ANDROID_NDK_HOME=~/android-ndk-r26d
```

### Q2: 编译速度慢
手机编译较慢，可能需要 5-15 分钟。建议插电并保持屏幕常亮。

### Q3: 内存不足
如果手机内存小（< 4GB），编译可能失败。建议使用交换分区：

```bash
# 创建 2GB 交换文件
dd if=/dev/zero of=/swapfile bs=1M count=2048
chmod 600 /swapfile
mkswap /swapfile
swapon /swapfile

# 编译完成后关闭
swapoff /swapfile
rm /swapfile
```

## 验证编译结果

```bash
file libs/arm64-v8a/libcpuinfo_spoofer.so
# 应显示：ELF 64-bit LSB shared object, ARM aarch64
```

## 下一步

编译成功后，参考 `INSTALL.md` 进行模块打包和安装。