#!/system/bin/sh
# customize.sh - Magisk module customizer
# 此脚本在模块安装时运行，用于根据设备调整配置

ui_print " "
ui_print "  CPU Info Spoofer"
ui_print "  Customizing for your device..."

# 获取设备信息
API=$(getprop ro.build.version.sdk)
ABI=$(getprop ro.product.cpu.abi)
DEVICE=$(getprop ro.product.device)

ui_print "  Device: $DEVICE"
ui_print "  API Level: $API"
ui_print "  ABI: $ABI"

# 根据设备调整伪装信息
case "$DEVICE" in
    # 华为设备
    *"an"*|*"ocean"*|*"hima"*|*"long"*|*"angela"*|*"berlin"*)
        ui_print "  Detected Huawei device, applying Kirin 9000S spoof..."
        PROP_HARDWARE="chagall"
        PROP_SOC="kirin9000s"
        ;;
    # 三星设备
    *"exynos"*|*"beyond"*|*"d2"*|*"n9"*)
        ui_print "  Detected Samsung device, applying Exynos 2400 spoof..."
        PROP_HARDWARE="exynos2400"
        PROP_SOC="exynos2400"
        ;;
    # 小米设备
    *"mi"*|*"redwood"*|*"manet"*|*"moon"*|*"ruby"*|*"cupid"*)
        ui_print "  Detected Xiaomi device, applying Snapdragon 8 Gen 2 spoof..."
        PROP_HARDWARE="mt6985" # 天玑 9200+ 或对应的 Qualcomm
        PROP_SOC="sm8550"
        ;;
    # 默认
    *)
        ui_print "  Using default Kirin 9000S spoof..."
        PROP_HARDWARE="chagall"
        PROP_SOC="kirin9000s"
        ;;
esac

ui_print "  Hardware: $PROP_HARDWARE"
ui_print "  SoC: $PROP_SOC"

# 写入临时配置文件
TMP_FILE=$TMPDIR/props.conf
cat << EOF > $TMP_FILE
ro.hardware=$PROP_HARDWARE
ro.soc.model=$PROP_SOC
ro.chipname=$PROP_SOC
EOF

ui_print "  Configuration saved."

# 将配置文件复制到模块目录（可选，供高级用户修改）
cp $TMP_FILE $MODPATH/spoof_config.txt 2>/dev/null

ui_print "  Installation complete!"
ui_print "  Please reboot your device."
ui_print " "