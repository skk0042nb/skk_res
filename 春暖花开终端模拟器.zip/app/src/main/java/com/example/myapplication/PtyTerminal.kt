package com.example.myapplication

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.nio.charset.Charset

class PtyTerminal {
    private var fd: Int = -1
    private var pid: Int = -1
    private var readJob: Job? = null

    val isRunning: Boolean
        get() = fd >= 0 && pid > 0

    fun start(
        scope: CoroutineScope,
        command: String,
        rows: Int = 32,
        cols: Int = 100,
        onOutput: (String) -> Unit,
        onExit: () -> Unit
    ) {
        close()
        val result = nativeStart(command, rows, cols)
            ?: throw IllegalStateException("无法创建 PTY")
        fd = result[0]
        pid = result[1]

        readJob = scope.launch(Dispatchers.IO) {
            try {
                while (isRunning) {
                    val bytes = nativeRead(fd, 4096)
                    if (bytes.isEmpty()) break
                    onOutput(bytes.toString(Charset.defaultCharset()))
                }
            } finally {
                close()
                onExit()
            }
        }
    }

    fun write(text: String) {
        if (!isRunning) return
        nativeWrite(fd, text.toByteArray(Charset.defaultCharset()))
    }

    fun resize(rows: Int, cols: Int) {
        if (!isRunning) return
        nativeResize(fd, rows, cols)
    }

    fun close() {
        val oldFd = fd
        val oldPid = pid
        fd = -1
        pid = -1
        readJob?.cancel()
        readJob = null
        if (oldFd >= 0 || oldPid > 0) {
            nativeClose(oldFd, oldPid)
        }
    }

    private external fun nativeStart(command: String, rows: Int, cols: Int): IntArray?
    private external fun nativeRead(fd: Int, maxBytes: Int): ByteArray
    private external fun nativeWrite(fd: Int, data: ByteArray): Int
    private external fun nativeResize(fd: Int, rows: Int, cols: Int)
    private external fun nativeClose(fd: Int, pid: Int)

    companion object {
        init {
            System.loadLibrary("ptyterminal")
        }
    }
}
