package com.example.myapplication

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.io.BufferedReader
import java.io.InputStreamReader
import java.nio.charset.Charset

class PtyTerminal {
    private var process: Process? = null
    private var readJob: Job? = null
    private var outputThread: Thread? = null

    val isRunning: Boolean
        get() = process?.isAlive == true && readJob?.isActive == true

    fun start(
        scope: CoroutineScope,
        command: String,
        rows: Int = 32,
        cols: Int = 100,
        onOutput: (String) -> Unit,
        onExit: () -> Unit
    ) {
        close()
        try {
            val cmdList = if (command.startsWith("su")) {
                listOf("sh", "-c", command)
            } else {
                listOf("sh", "-c", command)
            }
            
            process = ProcessBuilder(cmdList)
                .redirectErrorStream(true)
                .start()

            readJob = scope.launch(Dispatchers.IO) {
                try {
                    val reader = BufferedReader(InputStreamReader(process!!.inputStream, Charset.defaultCharset()))
                    var line: String?
                    while (isRunning) {
                        line = reader.readLine()
                        if (line == null) break
                        withContext(Dispatchers.Main) {
                            onOutput(line + "\n")
                        }
                    }
                } finally {
                    close()
                    onExit()
                }
            }
        } catch (e: Exception) {
            throw IllegalStateException("无法启动终端: ${e.message}")
        }
    }

    fun write(text: String) {
        if (!isRunning) return
        try {
            val stream = process?.outputStream ?: return
            stream.write(text.toByteArray(Charset.defaultCharset()))
            stream.flush()
        } catch (e: Exception) {
            // ignore write errors
        }
    }

    fun resize(rows: Int, cols: Int) {
        // Not supported in pure Java implementation
    }

    fun close() {
        readJob?.cancel()
        readJob = null
        outputThread?.interrupt()
        outputThread = null
        try {
            process?.destroy()
        } catch (e: Exception) {
            // ignore
        }
        process = null
    }
}
