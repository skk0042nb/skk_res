#!/system/bin/sh
# ============================================================
#  TrickyStore 一键密钥更新脚本 (Keybox Only)
#  功能：自动从多个源获取有效 Keybox，一个不行自动换下一个
#  用法：su 后直接 sh 运行，无需任何交互
# ============================================================

TS_DIR="/data/adb/tricky_store"
TARGET_KEYBOX="$TS_DIR/keybox.xml"
TMP_DIR="/data/local/tmp/keybox_update"
TMP_RAW="$TMP_DIR/raw.tmp"
TMP_KEYBOX="$TMP_DIR/keybox_tmp.xml"

# ---- 三个数据源 ----
YURIKEY_URL="https://raw.githubusercontent.com/Yurii0307/yurikey/main/key"
TRICKYADDON_URL="https://raw.githubusercontent.com/KOWX712/Tricky-Addon-Update-Target-List/keybox/.extra"
INTEGRITYBOX_URL="https://raw.githubusercontent.com/MeowDump/MeowDump/refs/heads/main/NullVoid/OptimusPrime"

# ---- 备用镜像（IntegrityBox 官方源不可用时尝试） ----
INTEGRITYBOX_JSDELIVR="https://cdn.jsdelivr.net/gh/MeowDump/MeowDump@main/NullVoid/OptimusPrime"

# ---- GitHub 代理列表（依次尝试） ----
PROXY_LIST="
https://ghfile.geekertao.top/
https://github.dpik.top/
https://gh.felicity.ac.cn/
https://gh.llkk.cc/
https://api-ghp.fjy.zone/
"

# ---- 颜色 ----
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

TOYBOX_COMMANDS=""
BUSYBOX_COMMANDS=""

# ============================================================
#  基础工具函数
# ============================================================

init_command_cache() {
  local toybox_out busybox_out
  if command -v toybox >/dev/null 2>&1; then
    toybox_out=$(toybox --list 2>/dev/null | tr '\n' ' ')
    TOYBOX_COMMANDS=" $toybox_out "
  fi
  if command -v busybox >/dev/null 2>&1; then
    busybox_out=$(busybox --list 2>/dev/null | tr '\n' ' ')
    BUSYBOX_COMMANDS=" $busybox_out "
  fi
}

# 智能命令执行：优先 toybox → busybox → 系统
run() {
  local cmd="$1"
  shift
  case "$TOYBOX_COMMANDS" in
    *" $cmd "*) toybox "$cmd" "$@"; return $? ;;
  esac
  case "$BUSYBOX_COMMANDS" in
    *" $cmd "*) busybox "$cmd" "$@"; return $? ;;
  esac
  if command -v "$cmd" >/dev/null 2>&1; then
    "$cmd" "$@"; return $?
  fi
  printf "${RED}[ERROR]${NC} 命令 '%s' 不可用\n" "$cmd" >&2
  return 127
}

log_info()  { printf "${GREEN}[INFO]${NC} %s\n" "$1"; }
log_warn()  { printf "${YELLOW}[WARN]${NC} %s\n" "$1" >&2; }
log_error() { printf "${RED}[ERROR]${NC} %s\n" "$1" >&2; }

# ============================================================
#  下载函数（核心）：自动遍历代理，三套下载工具
#  参数：$1=原始URL  $2=目标文件
#  返回：0=成功  1=全部失败
# ============================================================
download_file() {
  local original_url="$1"
  local dest="$2"
  local url_list=""

  # 构建 URL 列表：直连 + 每个代理前缀
  url_list="$original_url"
  for proxy in $PROXY_LIST; do
    [ -n "$proxy" ] && url_list="$url_list
${proxy}${original_url}"
  done

  # 每个 URL 尝试 curl → busybox wget → toybox wget
  local url tool success
  for url in $url_list; do
    [ -z "$url" ] && continue
    case "$url" in
      "$original_url") log_info "尝试直连: $original_url" ;;
      *)               log_info "尝试代理: $url" ;;
    esac

    run rm -f "$dest"
    success=1

    # 1) curl
    if command -v curl >/dev/null 2>&1; then
      curl -fL -sS --connect-timeout 10 --retry 1 "$url" -o "$dest" 2>/dev/null && success=0
    fi

    # 2) busybox wget
    if [ "$success" -ne 0 ]; then
      case "$BUSYBOX_COMMANDS" in
        *" wget "*)
          busybox wget -T 10 -t 2 --no-check-certificate -q -O "$dest" "$url" 2>/dev/null && success=0
          ;;
      esac
    fi

    # 3) toybox wget
    if [ "$success" -ne 0 ]; then
      case "$TOYBOX_COMMANDS" in
        *" wget "*)
          toybox wget -T 10 -t 2 --no-check-certificate -q -O "$dest" "$url" 2>/dev/null && success=0
          ;;
      esac
    fi

    if [ "$success" -eq 0 ] && [ -s "$dest" ]; then
      log_info "✅ 下载成功"
      return 0
    fi
  done

  log_error "❌ 所有下载方式均失败: $original_url"
  run rm -f "$dest"
  return 1
}

# ============================================================
#  源1: Yurikey — 单层 base64 解码
# ============================================================
fetch_yurikey() {
  log_info "━━━ 尝试源 [Yurikey] ━━━"
  if ! download_file "$YURIKEY_URL" "$TMP_RAW"; then
    return 1
  fi
  log_info "正在解码 (base64)..."
  run tr -d '\n\r ' < "$TMP_RAW" | run base64 -d > "$TMP_KEYBOX" 2>/dev/null
  if [ ! -s "$TMP_KEYBOX" ]; then
    log_error "解码后文件为空"
    return 1
  fi
  return 0
}

# ============================================================
#  源2: Tricky Addon — xxd -r -p | base64 -d
# ============================================================
fetch_tricky_addon() {
  log_info "━━━ 尝试源 [Tricky Addon] ━━━"
  if ! download_file "$TRICKYADDON_URL" "$TMP_RAW"; then
    return 1
  fi
  log_info "正在解码 (xxd + base64)..."
  run tr -d '\n\r ' < "$TMP_RAW" | run xxd -r -p 2>/dev/null | run base64 -d > "$TMP_KEYBOX" 2>/dev/null
  if [ ! -s "$TMP_KEYBOX" ]; then
    log_error "解码后文件为空"
    return 1
  fi
  return 0
}

# ============================================================
#  源3: IntegrityBox — 10层base64 → xxd -r -p → ROT13
# ============================================================
fetch_integritybox() {
  local url="$1"
  log_info "━━━ 尝试源 [IntegrityBox] ━━━"
  if ! download_file "$url" "$TMP_RAW"; then
    return 1
  fi

  local process="$TMP_DIR/process.tmp"
  local next="$TMP_DIR/process.next"
  local clean="$TMP_DIR/clean.tmp"
  local i=1

  run tr -d '\n\r ' < "$TMP_RAW" > "$process"

  log_info "正在解码 (10层Base64)..."
  while [ "$i" -le 10 ]; do
    [ ! -s "$process" ] && { log_error "第 $i 层数据为空，中断"; return 1; }
    run tr -d '\n\r ' < "$process" > "$clean"
    if ! run base64 -d "$clean" > "$next" 2>/dev/null; then
      log_error "第 $i 层 Base64 解码失败"
      return 1
    fi
    run mv -f "$next" "$process"
    i=$((i + 1))
  done

  log_info "正在最终格式转换 (xxd + ROT13)..."
  if ! run cat "$process" | run xxd -r -p 2>/dev/null | run tr 'A-Za-z' 'N-ZA-Mn-za-m' > "$TMP_KEYBOX"; then
    log_error "最终格式转换失败"
    return 1
  fi
  if [ ! -s "$TMP_KEYBOX" ]; then
    log_error "最终文件为空"
    return 1
  fi
  return 0
}

# ============================================================
#  校验 keybox.xml 合法性
# ============================================================
validate_keybox() {
  local file="$1"
  if [ ! -s "$file" ]; then
    log_error "Keybox 文件为空"
    return 1
  fi
  if ! run grep -q "<?xml" "$file"; then
    log_error "Keybox 缺少 XML 声明"
    return 1
  fi
  if ! run grep -q "<AndroidAttestation>" "$file"; then
    log_error "Keybox 缺少 AndroidAttestation 标签"
    return 1
  fi
  if ! run grep -q "BEGIN CERTIFICATE" "$file"; then
    log_error "Keybox 缺少证书内容"
    return 1
  fi
  local size
  size=$(run wc -c < "$file" 2>/dev/null | run tr -d ' ')
  log_info "✅ Keybox 校验通过 (${size} 字节)"
  return 0
}

# ============================================================
#  安装到目标位置
# ============================================================
install_keybox() {
  if run mv -f "$TMP_KEYBOX" "$TARGET_KEYBOX"; then
    run chmod 644 "$TARGET_KEYBOX"
    log_info "✅ Keybox 已安装到 $TARGET_KEYBOX"
    return 0
  else
    log_error "写入 $TARGET_KEYBOX 失败（权限问题？）"
    return 1
  fi
}

# ============================================================
#  主流程：依次尝试所有源，成功即停
# ============================================================
main() {
  printf "${CYAN}"
  printf "╔══════════════════════════════════════╗\n"
  printf "║   TrickyStore 一键密钥更新 (Keybox)  ║\n"
  printf "║   多源自动切换 · 代理自动遍历 · 零交互 ║\n"
  printf "╚══════════════════════════════════════╝\n"
  printf "${NC}"

  # 初始化
  init_command_cache
  run rm -rf "$TMP_DIR"
  run mkdir -p "$TMP_DIR"
  run mkdir -p "$TS_DIR"

  # 备份旧 keybox
  if [ -f "$TARGET_KEYBOX" ]; then
    run cp -f "$TARGET_KEYBOX" "$TARGET_KEYBOX.bak"
    log_info "已备份旧 Keybox → keybox.xml.bak"
  fi

  # ---- 尝试顺序：Yurikey → Tricky Addon → IntegrityBox(官方) → IntegrityBox(jsDelivr) ----
  local success=0

  if fetch_yurikey && validate_keybox "$TMP_KEYBOX"; then
    success=1
  elif fetch_tricky_addon && validate_keybox "$TMP_KEYBOX"; then
    success=1
  elif fetch_integritybox "$INTEGRITYBOX_URL" && validate_keybox "$TMP_KEYBOX"; then
    success=1
  elif fetch_integritybox "$INTEGRITYBOX_JSDELIVR" && validate_keybox "$TMP_KEYBOX"; then
    success=1
  else
    log_error "══════════════════════════════"
    log_error "  所有源均获取失败！"
    log_error "  请检查："
    log_error "  1. 网络是否正常"
    log_error "  2. GitHub 是否可访问"
    log_error "  3. 尝试手动设置代理后重跑"
    log_error "══════════════════════════════"
    success=0
  fi

  # 安装
  if [ "$success" -eq 1 ]; then
    if install_keybox; then
      printf "\n${GREEN}████████████████████████████████████████${NC}\n"
      printf "${GREEN}  ✅ Keybox 更新完成！${NC}\n"
      printf "${GREEN}  📄 文件: %s${NC}\n" "$TARGET_KEYBOX"
      printf "${GREEN}  📊 大小: %s 字节${NC}\n" "$(run wc -c < "$TARGET_KEYBOX" 2>/dev/null | run tr -d ' ')"
      printf "${GREEN}████████████████████████████████████████${NC}\n"
      printf "\n${YELLOW}提示：请重启设备或在 Magisk/KernelSU 中刷新模块使 Keybox 生效${NC}\n"
    fi
  fi

  # 清理
  run rm -rf "$TMP_DIR"
  log_info "临时文件已清理"
}

main
